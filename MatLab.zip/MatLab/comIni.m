%Leo el puerto COM seleccionado
NCOM = get(handles.PopUpMenu,'value');
NCOMstr = num2str(NCOM);
COM = ['COM',NCOMstr];

%Inicializaci�n del puerto serial
delete(instrfind({'Port'},{COM}));
puerto_serial = serial(COM);
puerto_serial.BaudRate = 9600;
warning('off','MATLAB:serial:fscanf:unsuccessfulRead');

%Abro el puerto serial
fopen(puerto_serial);

axes(handles.Tabla1);
cla; %Limpia la gr�fica
title('I/V');
xlabel('Vin (V)');
ylabel('Iin (A)');
grid on;
hold on;
axes(handles.Tabla2);
cla;
title('P/V');
xlabel('Vin (V)');
ylabel('Pin (W)');
grid on;
hold on;

%Detenmos la ejecuci�n del programa durante dos segundos para generar  la
%ventan y dejar MatLab listo para recibir muestras.
pause(2);

%Envio el dato que activa la calibraci�n en Arduino "1".
fprintf(puerto_serial,'%d',1);

%Recibo el n�mero de muestras que me va a enviar Arduino
m = fscanf(puerto_serial,'%d');
%Mientras arduino env�en muestras MatLab estar� recibiendo
cnt = 1;
%Variables que almacenar�n los valores m�ximos de V,I y P.
maxV = 0;
maxI = 0;
maxP = 0;
VmaxP = 0;

while cnt <= m+1
    %Loe los datos que me env�a aruino
    Iin(cnt) = fscanf(puerto_serial,'%f')/1000; %para pasar a amperios.
    Vin(cnt) = fscanf(puerto_serial,'%f');
    Pin(cnt) = fscanf(puerto_serial,'%f')/1000; %par pasar a W
    %Almaceno el m�ximo de V,I y P para saber el l�mite de la gr�fica
    if Vin(cnt)>maxV
        %Si el valor recibido es mayor lo almaceno y ajusto el l�mite
        maxV=Vin(cnt);
        axes(handles.Tabla1);
        xlim([0 maxV]);
        axes(handles.Tabla2);
        xlim([0 maxV]);
    end
    if Iin(cnt)>maxI
        maxI=Iin(cnt);
        axes(handles.Tabla1);
        ylim([0 maxI+Iin(cnt)/5]);
    end
    if Pin(cnt)>maxP
        maxP=Pin(cnt);
        VmaxP = Vin(cnt);
        axes(handles.Tabla2);
        ylim([0 maxP+Pin(cnt)/5]);
    end
    
    axes(handles.Tabla1);
    plot(Vin(cnt),Iin(cnt),'.','MarkerSize',20);
    axes(handles.Tabla2);
    plot(Vin(cnt),Pin(cnt),'*','MarkerSize',10,'MarkerEdgeColor','r');
    drawnow
    cnt=cnt+1;
end

%cierro el puerto serie
fclose(puerto_serial);
delete(puerto_serial);

%Pinto el m�ximo
axes(handles.Tabla2);
plot(VmaxP,maxP,'--mo','MarkerSize',15,'MarkerEdgeColor','g');

%Calculamos el fator de llenado
FF = maxP/(Iin(end)*Vin(1));
FFstr = num2str(FF);
set(handles.Fmerito,'String',FFstr);

%Muestro potencia m�xima
maxPstr = num2str(maxP);
set(handles.Mpower,'String',maxPstr);
