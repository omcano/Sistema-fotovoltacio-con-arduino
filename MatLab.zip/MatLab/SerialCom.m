%---------------------------------------------------------------------
% Este es c�digo MatLab implementado para el Trabajo Fin de Grado:
%          "Sistema fotovoltaico orientado a docencia". 
% Realizado por:       �scar Mart�nez cano
%
%
% Este programa crea una comunicaci�n serie, despu�s genera una gr�fica,
% cuyos l�mites se ajustaran din�micamente en funci�n de las muestras 
% recibidas y en la que se represetar�n las muestras obtenidas por el
% puerto serie. Despu�s se cierra la comunicaci�n y se calcula el factor de
% llenado a partir de las muestras recibidas
%
% Este software es de c�digo abierto y puede consultarse libremente.
%--------------------------------------------------------------------------
clear all;
close all;
clc;

%Inicializaci�n del puerto serial
delete(instrfind({'Port'},{'COM6'}));
puerto_serial = serial('COM6');
puerto_serial.BaudRate = 9600;
warning('off','MATLAB:serial:fscanf:unsuccessfulRead');

%Abro el puerto serial
fopen(puerto_serial);

%Creo una ventana para la gr�fica
figure('Name','Comunicaci�n serie con Arduino. By �scar Mart�nez cano');
subplot(2,1,1)
title('I/V');
xlabel('Vin (V)');
ylabel('Iin (A)');
grid on;
hold on;
subplot(2,1,2)
title('P/V');
xlabel('Vin (V)');
ylabel('Pin (W)');
grid on;
hold on;

%Variables que almacenar�n los valores m�ximos de V,I y P.
maxV = 0;
maxI = 0;
maxP = 0;
VmaxP = 0;

%Detenmos la ejecuci�n del programa durante dos segundos para generar  la
%ventan y dejar MatLab listo para recibir muestras.
pause(2);

%Envio el dato que activa la calibraci�n en Arduino "1".
fprintf(puerto_serial,'%d',1);

%Recibo el n�mero de muestras que me va a enviar Arduino
m = fscanf(puerto_serial,'%d');
%Mientras arduino env�en muestras MatLab estar� recibiendo
cnt = 1;
while cnt <= m+1
    %Loe los datos que me env�a aruino
    Iin(cnt) = fscanf(puerto_serial,'%f')/1000; %para pasar a amperios.
    Vin(cnt) = fscanf(puerto_serial,'%f');
    Pin(cnt) = fscanf(puerto_serial,'%f')/1000; %par pasar a W
    %Almaceno el m�ximo de V,I y P para saber el l�mite de la gr�fica
    if Vin(cnt)>maxV
        %Si el valor recibido es mayor lo almaceno y ajusto el l�mite
        maxV=Vin(cnt);
        subplot(2,1,1)
        xlim([0 maxV]);
        subplot(2,1,2)
        xlim([0 maxV]);
    end
    if Iin(cnt)>maxI
        maxI=Iin(cnt);
        subplot(2,1,1)
        %En este l�mite sumamos un poco porque la corriente tiene una zona
        %lineal en la que los valores son iguales y puede que aparezcan en
        %el l�mete de la gr�fica, si sumamos un quinto del valor de la
        %�ltima muestra nos aseguramos de qeu aparezca
        ylim([0 maxI+Iin(cnt)/5]);
    end
    if Pin(cnt)>maxP
        maxP=Pin(cnt);
        VmaxP = Vin(cnt);
        subplot(2,1,2)
        ylim([0 maxP]);
    end
    
    subplot(2,1,1);
    plot(Vin(cnt),Iin(cnt),'.','MarkerSize',20);
    subplot(2,1,2);
    plot(Vin(cnt),Pin(cnt),'*','MarkerSize',10,'MarkerEdgeColor','r');
    drawnow
    cnt=cnt+1;
end

%cierro el puerto serie
fclose(puerto_serial);
delete(puerto_serial);

%Pinto el m�ximo
subplot(2,1,2);
plot(VmaxP,maxP,'--mo','MarkerSize',15,'MarkerEdgeColor','g');

%Calculamos el fator de llenado
FF = maxP/(Iin(end)*Vin(1));

%Muestro los datos
disp('Potencia m�xima (W)');
maxP
disp('Factor de llenado (Fill Factor)');
FF
